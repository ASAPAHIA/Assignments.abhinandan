import java.util.*;

public class Testdemo
{
public static void main(String args[])
{
	Random rand=new Random();
	Account smith=new Account();
	Person psmith= new Person();
	psmith.setName("Smith");
	psmith.setAge(20);
	smith.setAccHolder(psmith);
	smith.setAccountBal(2000);
	smith.setAccountNum(Math.abs(rand.nextLong()));
	
	Account kathy=new Account();
	Person pkathy= new Person();
	 pkathy.setName("kathy");
	 pkathy.setAge(20);
	 kathy.setAccHolder( pkathy);
	 kathy.setAccountBal(2000);
	 kathy.setAccountNum(Math.abs(rand.nextLong()));
	 
	 smith.deposite(2000);
	 System.out.println("smiths balance="+smith.getBalance());
	 kathy.withDraw(2000);
	 System.out.println("kathys balance="+kathy.getBalance());
	 SavingAccount svAccount=new SavingAccount();
	 svAccount.setAccountBal(5000);
	 svAccount.withDraw(500);
	 
	 CurrentAcc crAccount=new CurrentAcc();
	 crAccount.setOverdftLimit(5000);
	 crAccount.setAccountBal(5000);
	 crAccount.withDraw(500);
}
}