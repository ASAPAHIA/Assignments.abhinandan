
public  class CurrentAcc extends Account 
{
 double overDftLim;
 public double getOverdftLimit()
 {
	 return overDftLim;
 }
 public void setOverdftLimit(double overDftLim)
 {
	 this.overDftLim=overDftLim;
 }
 public void withDraw(double amount)
 {
	 boolean status;
	 status=checkOvDft(amount);
	 if(status==true)
	 {
		 accountBal=accountBal-amount;
		 System.out.println("balance="+accountBal);
	 }
 }
 public boolean checkOvDft(double amount)
 {
	 boolean status;
	 if(amount>overDftLim)
	 {
		 status=false;
		 System.out.println("no funds");
	 }
	 else if(accountBal-amount<overDftLim)
	 {
		 System.out.println("unsuccessful transaction");
		 status =false;
	 }
	 else
	 {
		 accountBal=accountBal-amount;
		 System.out.println("balance="+accountBal);
		 status =true;
	 }
	 return status;
 }
}
