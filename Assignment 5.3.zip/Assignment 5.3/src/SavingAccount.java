
public  class SavingAccount extends Account
{ 
	
	final double minBalance=500;
	
	public double getMinBalance()
	{
		return minBalance;
	}
public void withDraw(double amount)
{
	if(amount>accountBal)
	{
		System.out.println("no funds");
	}
	else if(accountBal-amount<minBalance)
	{
		System.out.println("low balance");
	}
	else
	{
		accountBal=accountBal-amount;
		System.out.println("balance="+accountBal);
	}
}

}