
public class TestCamera 
{
public static void main(String args[])
{
Camera1 c1=new Camera1();
Camera c2=new Camera2();
System.out.println(c1.type());

System.out.println(c1.company());

System.out.println(c2.type());

System.out.println(c2.company());
}
}
