
public class Camera2 implements Camera
{

	@Override
	public String type() {
		
		return "reel camera";
	}

	@Override
	public String company() {
		
		return "sony";
	}

}
