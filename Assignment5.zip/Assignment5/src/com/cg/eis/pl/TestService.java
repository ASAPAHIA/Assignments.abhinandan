package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.service.Service;

public class TestService 
{
public static void main(String args[])
{
//	Scanner sc=new Scanner(System.in);
	Service es=new Service();
	es.putDetail();
	es.showDetails();
}
}
