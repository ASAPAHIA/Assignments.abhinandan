package com.cg.eis.service;
import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Service extends Employee implements EmployeeService
{
	Employee emp=new Employee();
	Scanner sc=new Scanner(System.in);
	public void showDetails()
	{
		System.out.println("id="+emp.getId());
		System.out.println("name="+emp.getName());
		System.out.println("salary="+emp.getSalary());
		System.out.println("designation="+emp.getDesignation());
		System.out.println("InsuranceScheme="+emp.getInsuranceScheme());
	}

	public void putDetail()
	{
		System.out.println("id,name,salary,designation,insurancescheme");
		emp.setId(sc.nextInt());
		emp.setSalary(sc.nextDouble());
		emp.setName(sc.next());
		emp.setDesignation(sc.next());
		emp.setInsuranceScheme(getInsuranceScheme(emp.getSalary(),emp.getDesignation()));
	}
	public String getInsuranceScheme(double sal,String design) {
		String insuranceScheme=null;

		if(sal<5000 && design.equals("clerk"))
		{
			insuranceScheme="no scheme";
		}
		else if(sal>5000 && sal<20000 &&design.equals("System Associate"))
		{
			insuranceScheme="Scheme C";
		}
		else if(sal>20000 && sal<40000 &&design.equals("Programmer"))
		{
			insuranceScheme="Scheme b";
		}
		if(sal>=40000 && design.equals("Manager"))
		{
			insuranceScheme="Scheme a";
		}
		return insuranceScheme;
	}

}


