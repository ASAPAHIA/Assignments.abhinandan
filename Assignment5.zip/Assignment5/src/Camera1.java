
public class Camera1 implements Camera 
{

	@Override
	public String type() {
		
		return "dslr";
	}

	@Override
	public String company() {
		
		return "canon";
	}

	
	}


