
public interface Camera 
{

	public String type();
	public String company();
}
