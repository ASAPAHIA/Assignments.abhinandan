

import java.util.Scanner;


public class PersonDetailenum {
	public static void main(String a[])
	{
		Scanner sc=new Scanner(System.in);
		EnumPersonalDetail employeedetail;
		System.out.println("enter detail 1:male,2:female");
		int index=sc.nextInt();
		switch(index)
		{
		case 1:employeedetail=EnumPersonalDetail.male;
		break;
		default:employeedetail=EnumPersonalDetail.female;
	}
System.out.println(employeedetail);
}
}
