
public class Persondetail {
String Fname;
String Lname;
EnumPersonalDetail gender;
long num;
public Persondetail(String f,String l,EnumPersonalDetail g,long n)
{
	
	fill(f,l,g,n);
}
public void fill(String f,String l,EnumPersonalDetail g,long n)
{
	Fname=f;
	Lname=l;
	gender=g;
	num=n;
}
public void dispname()
{
System.out.println(Fname);

System.out.println(Lname);

System.out.println(gender);

System.out.println(num);
}

}
