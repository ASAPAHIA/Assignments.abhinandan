
public enum EnumPersonalDetail {
male,female;
}
