
public class Testpos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 if(Integer.parseInt(args[0])>0)
 {
	 System.out.println("positive");
 }
 else
 {
	 System.out.println("negative");
 }
	}

}
