
public class Personaldetail
{
String Fname;
String Lname;
char gender;
int age;
double weight;
public void call(String f,String l,char g,int a,double w)
{
	Fname=f;
	Lname=l;
	gender=g;
			age=a;
			weight=w;
			
}
public void disp()
{
	System.out.println(Fname);

	System.out.println(Lname);

	System.out.println(gender);

	System.out.println(age);

	System.out.println(weight);
}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
Personaldetail pd=new Personaldetail();
pd.call("divya", "bharti", 'F', 20,85.55 );
pd.disp();		
	}

}
