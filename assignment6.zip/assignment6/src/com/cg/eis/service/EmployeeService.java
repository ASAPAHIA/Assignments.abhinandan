package com.cg.eis.service;
import com.cg.eis.bean.*;

public interface EmployeeService
{
	
public String getInsuranceScheme(double sal,String design);

//String print();
}
