import java.io.IOException;


 class PersonDetail {
public String fname;
public String lname;
public String gender;

public PersonDetail(String f,String l,String g)
{
	fname=f;
	lname=l;
	gender=g;
	
}
public void dispname()
{
System.out.println(fname);

System.out.println(lname);

System.out.println(gender);

}
}
public class TestException
{
	public static void main(String args[])
	{
		PersonDetail pd=new PersonDetail(null,null, "M" );
		if(pd.fname.equals(null) && pd.lname.equals(null))
		{
		throw new UserDedinedException("blank name");	
		}
		
	}
}